import React, { useEffect, useState } from "react";

/**
 * AnonLetters — Single-file React app
 * - Default export is a React component ready to drop into a React app (Vite / Create React App).
 * - Uses Tailwind CSS utility classes for styling (assumes Tailwind is configured in host project).
 * - Stores letters in localStorage and can produce shareable links (encoded in URL hash).
 * - Includes: anonymous toggle, public "wall", private share link, download/print, report flag.
 *
 * NOTE / Next steps (backend ideas):
 * - To make letters truly persistent across users, add a tiny backend (serverless function) with a DB.
 * - Implement moderation queue, CAPTCHA, rate-limiting, and optional email delivery.
 * - For production privacy: encrypt private letters before sending to server.
 */

export default function AnonLettersApp() {
  const STORAGE_KEY = "anonletters_data_v1";

  const [letters, setLetters] = useState([]);
  const [wallView, setWallView] = useState("public"); // public | private | mine
  const [form, setForm] = useState({
    recipient: "",
    subject: "",
    body: "",
    fromName: "",
    anonymous: true,
    visibility: "private", // private | public
  });
  const [notice, setNotice] = useState(null);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        setLetters(JSON.parse(raw));
      } catch (e) {
        console.error("Failed to parse storage", e);
      }
    }

    // If there's a hash in URL, try to load that letter
    if (window.location.hash.startsWith("#L:")) {
      const payload = window.location.hash.slice(3);
      try {
        const json = JSON.parse(decodeURIComponent(atob(payload)));
        setSelected(json);
      } catch (e) {
        console.warn("Can't parse shared letter", e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(letters));
  }, [letters]);

  function handleChange(e) {
    const { name, type, value, checked } = e.target;
    setForm((s) => ({ ...s, [name]: type === "checkbox" ? checked : value }));
  }

  function clearForm() {
    setForm({ recipient: "", subject: "", body: "", fromName: "", anonymous: true, visibility: "private" });
  }

  function saveLetter() {
    if (!form.body.trim()) {
      setNotice({ type: "error", text: "Write something first. Even a single line counts." });
      return;
    }
    const letter = {
      id: Math.random().toString(36).slice(2, 9),
      recipient: form.recipient.trim(),
      subject: form.subject.trim(),
      body: form.body.trim(),
      fromName: form.anonymous ? null : form.fromName.trim() || "(no name)",
      anonymous: !!form.anonymous,
      visibility: form.visibility,
      createdAt: new Date().toISOString(),
      flagged: false,
    };

    setLetters((s) => [letter, ...s]);
    setNotice({ type: "success", text: "Saved locally. You can share a link or publish to the wall." });
    clearForm();
  }

  function publishToWall(id) {
    setLetters((s) => s.map((l) => (l.id === id ? { ...l, visibility: "public" } : l)));
    setNotice({ type: "success", text: "Published to the public wall." });
  }

  function deleteLetter(id) {
    if (!confirm("Delete this letter from your browser storage? This is irreversible locally.")) return;
    setLetters((s) => s.filter((l) => l.id !== id));
    setNotice({ type: "success", text: "Deleted." });
  }

  function flagLetter(id) {
    setLetters((s) => s.map((l) => (l.id === id ? { ...l, flagged: true } : l)));
    setNotice({ type: "warn", text: "Flagged for review (local). In production this would notify moderators." });
  }

  function shareLink(letter) {
    const payload = btoa(encodeURIComponent(JSON.stringify(letter)));
    const url = `${window.location.origin}${window.location.pathname}#L:${payload}`;
    navigator.clipboard
      .writeText(url)
      .then(() => setNotice({ type: "success", text: "Share link copied to clipboard." }))
      .catch(() => setNotice({ type: "error", text: "Couldn't copy — here's the link:" + url }));
  }

  function downloadText(letter) {
    const blob = new Blob([formatLetterText(letter)], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `letter-${letter.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function formatLetterText(letter) {
    return `To: ${letter.recipient || "(unspecified)"}\nSubject: ${letter.subject || "(no subject)"}\nFrom: ${
      letter.anonymous ? "(anonymous)" : letter.fromName || "(no name)"
    }\nDate: ${new Date(letter.createdAt).toLocaleString()}\n\n${letter.body}`;
  }

  function printLetter(letter) {
    const w = window.open("", "_blank");
    w.document.write(`<pre style='white-space:pre-wrap;font-family:system-ui;padding:20px;'>${escapeHtml(
      formatLetterText(letter)
    )}</pre>`);
    w.document.close();
    w.print();
  }

  function escapeHtml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  const visibleLetters = letters.filter((l) => {
    if (wallView === "public") return l.visibility === "public";
    if (wallView === "mine") return l.visibility && l.visibility !== "public";
    return true;
  });

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center p-6">
      <div className="w-full max-w-4xl">
        <header className="flex items-center justify-between py-6">
          <h1 className="text-2xl font-extrabold">AnonLetters</h1>
          <div className="space-x-2">
            <button className="px-3 py-1 rounded-lg border text-sm" onClick={() => { setWallView("public"); setNotice(null); }}>Public wall</button>
            <button className="px-3 py-1 rounded-lg border text-sm" onClick={() => { setWallView("mine"); setNotice(null); }}>My drafts</button>
            <button className="px-3 py-1 rounded-lg border text-sm" onClick={() => { setWallView("all"); setNotice(null); }}>All (local)</button>
          </div>
        </header>

        {notice && (
          <div className={`mb-4 p-3 rounded-md text-sm ${notice.type === "success" ? "bg-green-100" : notice.type === "error" ? "bg-red-100" : "bg-yellow-100"}`}>
            {notice.text}
          </div>
        )}

        <main className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <section className="md:col-span-2 bg-white p-4 rounded-xl shadow-sm">
            <h2 className="font-semibold mb-2">Write a letter</h2>
            <label className="block text-sm text-gray-600">To (optional)</label>
            <input name="recipient" value={form.recipient} onChange={handleChange} className="w-full border rounded-md p-2 mb-3" placeholder="Recipient name, handle, or leave blank" />
            <label className="block text-sm text-gray-600">Subject (optional)</label>
            <input name="subject" value={form.subject} onChange={handleChange} className="w-full border rounded-md p-2 mb-3" placeholder="Short subject" />
            <label className="block text-sm text-gray-600">Message</label>
            <textarea name="body" value={form.body} onChange={handleChange} rows={6} className="w-full border rounded-md p-2 mb-3" placeholder="Write your letter..." />
            <div className="flex items-center gap-3 mb-3">
              <input id="anon" name="anonymous" type="checkbox" checked={form.anonymous} onChange={handleChange} />
              <label htmlFor="anon" className="text-sm">Send anonymously</label>
              {!form.anonymous && (<input name="fromName" value={form.fromName} onChange={handleChange} className="border rounded-md p-1 ml-2" placeholder="Your name" />)}
            </div>
            <div className="flex items-center justify-between">
              <div>
                <label className="text-sm mr-2">Visibility:</label>
                <select name="visibility" value={form.visibility} onChange={handleChange} className="border rounded-md p-1">
                  <option value="private">Private (default)</option>
                  <option value="public">Public (show on wall)</option>
                </select>
              </div>
              <div className="space-x-2">
                <button className="px-3 py-2 bg-blue-600 text-white rounded-md" onClick={saveLetter}>Save / Send</button>
                <button className="px-3 py-2 border rounded-md" onClick={() => { clearForm(); setNotice(null); }}>Clear</button>
              </div>
            </div>
          </section>

          <aside className="bg-white p-4 rounded-xl shadow-sm">
            <h3 className="font-semibold">Quick tips</h3>
            <ul className="text-sm mt-2 space-y-2">
              <li>🔒 Private letters are stored in your browser only.</li>
              <li>🌍 Public letters appear on the public wall.</li>
              <li>🔗 Use "Share" to create a link encoded in the URL hash.</li>
              <li>🚨 For production, add moderation & abuse controls.</li>
            </ul>
          </aside>
        </main>

        <section className="mt-6 bg-white p-4 rounded-xl shadow-sm">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Letters ({visibleLetters.length})</h2>
          </div>
          <div className="mt-4 space-y-3">
            {visibleLetters.length === 0 && <p className="text-sm text-gray-500">No letters yet — be the first.</p>}
            {visibleLetters.map((l) => (
              <article key={l.id} className="border rounded p-3 flex flex-col md:flex-row md:items-start md:justify-between">
                <div className="flex-1">
                  <div className="flex items-baseline justify-between">
                    <h3 className="font-medium">{l.subject || "(no subject)"}</h3>
                    <span className="text-xs text-gray-500">{new Date(l.createdAt).toLocaleString()}</span>
                  </div>
                  <p className="text-sm text-gray-700 mt-2 whitespace-pre-wrap">{l.body}</p>
                  <div className="text-xs text-gray-500 mt-2">To: {l.recipient || "—"} · From: {l.anonymous ? "(anonymous)" : l.fromName}</div>
                </div>
                <div className="mt-3 md:mt-0 md:ml-4 flex flex-col gap-2">
                  <button className="px-2 py-1 border rounded text-sm" onClick={() => shareLink(l)}>Share</button>
                  <button className="px-2 py-1 border rounded text-sm" onClick={() => downloadText(l)}>Download</button>
                  <button className="px-2 py-1 border rounded text-sm" onClick={() => printLetter(l)}>Print</button>
                  <button className="px-2 py-1 border rounded text-sm" onClick={() => publishToWall(l.id)}>Publish</button>
                  <button className="px-2 py-1 border rounded text-sm text-red-600" onClick={() => deleteLetter(l.id)}>Delete</button>
                  <button className="px-2 py-1 border rounded text-sm text-yellow-700" onClick={() => flagLetter(l.id)}>Flag</button>
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
